/* BuildInfo.h
 *
 *
 *
 */

#ifndef ___BuildInfo__h___
#define ___BuildInfo__h___

#define PRODUCT_BUILD_NUMBER	"2005.02"
#define PERLFILEVERSION		"5,8,6,811\0"
#define PERLRC_VERSION		5,8,6,811
#define ACTIVEPERL_CHANGELIST   ""
#define PERLPRODUCTVERSION	"Build " PRODUCT_BUILD_NUMBER ACTIVEPERL_CHANGELIST "\0"
#define PERLPRODUCTNAME		"IndigoPerl\0"

#define PERL_VENDORLIB_NAME	"IndigoSTAR"

#define ACTIVEPERL_VERSION	"Built " __DATE__ " " __TIME__
#define ACTIVEPERL_LOCAL_PATCHES_ENTRY	"IndigoPerl Build " PRODUCT_BUILD_NUMBER ACTIVEPERL_CHANGELIST
#define BINARY_BUILD_NOTICE	PerlIO_printf(PerlIO_stdout(), "\n\
Binary build " PRODUCT_BUILD_NUMBER ACTIVEPERL_CHANGELIST " provided by IndigoSTAR Software http://www.indigostar.com\n\
" ACTIVEPERL_VERSION "\n");

#endif  /* ___BuildInfo__h___ */
